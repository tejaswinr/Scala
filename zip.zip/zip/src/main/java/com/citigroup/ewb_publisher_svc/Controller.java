package com.citigroup.ewb_publisher_svc;


import com.citigroup.ewb.avro.Event;
import com.oracle.jrockit.jfr.EventToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class Controller {



    @RequestMapping(value ="/events" , method= RequestMethod.GET)
    public ResponseEntity<List<Event>> eventsGenerate(@RequestParam(value="input", defaultValue="1") String name) {

        int count = Integer.parseInt(name);

        System.out.println(" count --- "+count);

        ArrayList<Event> events = new ArrayList<Event>();

        for(int i = 0 ; i < count ; i++){
            Event e = EventGenerator.getNext();
            events.add(e);
        }
        System.out.println(" evetnts --- "+events);
        if (events.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
            // You many decide to return HttpStatus.NOT_FOUND
        }


        return new ResponseEntity<List<Event>>(events, HttpStatus.OK);

    }
}
