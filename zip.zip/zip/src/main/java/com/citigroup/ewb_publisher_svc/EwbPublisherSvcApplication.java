package com.citigroup.ewb_publisher_svc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EwbPublisherSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EwbPublisherSvcApplication.class, args);
	}
}
