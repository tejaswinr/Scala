>> For stand alone spring boot project (Tested on sts and intellij, runs fine from both)

Run Spring Boot Project First
Then run command npm install (first time and in case if you change package.json)
Then run command npm run dev-server
open localhost:8081 in your browser

>> For Spring boot multi module app (Tested on Intellij, fine -- in sts no luck)
Run Spring Boot Project of web module(Main program lies here only)
for react same as above
