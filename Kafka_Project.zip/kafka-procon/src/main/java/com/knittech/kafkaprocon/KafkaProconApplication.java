package com.knittech.kafkaprocon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaProconApplication {

    public static void main(String[] args) {
        SpringApplication.run(KafkaProconApplication.class, args);
    }
}
