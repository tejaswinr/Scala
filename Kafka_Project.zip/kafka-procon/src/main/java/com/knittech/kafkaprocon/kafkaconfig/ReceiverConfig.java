package com.knittech.kafkaprocon.kafkaconfig;

import com.knittech.kafkaprocon.model.FinancialDetails;
import com.knittech.kafkaprocon.model.PersonalDetails;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class ReceiverConfig {

    @Value(value = "${kafka.bootstrap-servers}")
    private String bootstrapServers;


    public ConsumerFactory<String, PersonalDetails> personalDetailsConsumerFactory(String groupId) {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(PersonalDetails.class));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, PersonalDetails> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, PersonalDetails> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(personalDetailsConsumerFactory("details"));
        return factory;
    }


    public ConsumerFactory<String, FinancialDetails> financialDetailsConsumerFactory(String groupId) {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(FinancialDetails.class));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, FinancialDetails> financialDetailsKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, FinancialDetails> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(financialDetailsConsumerFactory("details"));
        return factory;
    }

}
