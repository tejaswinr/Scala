import React from 'react';
import PieChartComponent from './PieChartComponent';

const PieChart = () => (
    <div className='container__list'>
        <PieChartComponent />
    </div>
);
export default PieChart;
