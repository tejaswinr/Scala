import React from 'react';
import DetailList from './DetailList';

const DetailTable = () => (
    <div className='container__list'>
        <DetailList />
    </div>
);

export default DetailTable;