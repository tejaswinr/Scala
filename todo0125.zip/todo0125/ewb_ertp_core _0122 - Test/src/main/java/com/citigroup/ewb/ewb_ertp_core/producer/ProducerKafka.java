package com.citigroup.ewb.ewb_ertp_core.producer;

import com.citigroup.ewb.TradeFile;
import com.citigroup.ewb.ewb_ertp_core.config.KafkaConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Component
public class ProducerKafka {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    Environment env;



    @Autowired
    KafkaConfig config;
    public void sendMessage(String message, String tf){


     //  System.out.println(tf.toString());
        ListenableFuture<SendResult<String, String>> future= kafkaTemplate.
                send(env.getProperty("kafka.topic"),message,tf);

        future.addCallback(
                new ListenableFutureCallback<SendResult<String,String>>() {

                    @Override
                    public void onFailure(Throwable ex) {
                        System.out.println(ex.getMessage());
                        System.out.println("Inside Exception");

                    }

                    @Override
                    public void onSuccess(SendResult<String, String> result) {
                        // TODO Auto-generated method stub
                        System.out.println("Inside Success");

                    }
                });


    }

}

//        HashMap<String, Object> props = (HashMap<String, Object>) config.producerConfigs();
//
//
//        Producer<String, TradeFile> producer = new KafkaProducer<String, TradeFile>(props);
//    TradeFile tf = TradeGenarater.getNext();
//        ProducerRecord producerRecord = new ProducerRecord(env.getProperty("kafka.topic"), tf);
//        producer.send(producerRecord);
//kafkaTemplate
//       .send(env.getProperty("kafka.topic"),message,tf);

//   TradeFile tf = TradeGenarater.getNext();