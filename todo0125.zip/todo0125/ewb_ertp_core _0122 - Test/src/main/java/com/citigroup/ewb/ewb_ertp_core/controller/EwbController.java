package com.citigroup.ewb.ewb_ertp_core.controller;

import com.citigroup.ewb.TradeFile;
import com.citigroup.ewb.ewb_ertp_core.utils.TradeGenarater;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.citigroup.ewb.ewb_ertp_core.service.CoreService;

import java.io.File;

@RestController
public class EwbController {



    @Autowired
    CoreService coreService;


    @RequestMapping(value="/home")
    public String getResult() {
        TradeFile tf = null;


            tf = TradeGenarater.getNext();
            System.out.println("tf ---  " + tf);
        return coreService.getResult(tf.toString());

        }

}
