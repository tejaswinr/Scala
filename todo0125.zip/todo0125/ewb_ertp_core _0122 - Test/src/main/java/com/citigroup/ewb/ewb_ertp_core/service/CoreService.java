package com.citigroup.ewb.ewb_ertp_core.service;

import com.citigroup.ewb.TradeFile;
import com.citigroup.ewb.ewb_ertp_core.producer.ProducerKafka;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class CoreService{

    @Autowired
    ProducerKafka producer;

    public String getResult(String tfJson){
        String key= String.valueOf(new Date().getTime());
        producer.sendMessage(key,tfJson);
        return tfJson;
    }
}


