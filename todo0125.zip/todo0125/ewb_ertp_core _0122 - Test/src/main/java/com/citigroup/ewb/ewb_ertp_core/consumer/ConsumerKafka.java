package com.citigroup.ewb.ewb_ertp_core.consumer;


import com.citigroup.ewb.TradeFile;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;

import java.util.concurrent.CountDownLatch;

public class ConsumerKafka  {



    @KafkaListener(id = "consumer", topics = {"${kafka.topic}"} )
    public void onMessage(ConsumerRecord<?, ?> record) throws Exception {


        System.out.println("Read Record is : " + record.value());
        System.out.println("Read Key is : " + record.key());
//    }
//
//    private CountDownLatch latch = new CountDownLatch(1);
//
//    public CountDownLatch getLatch() {
//        return latch;
//    }
//
//    @KafkaListener(topics = "${kafka.topic}")
//    public void receive(TradeFile trade) {
//        System.out.println("received Trade file = '{}' "+trade.toString());
//        latch.countDown();
    }




































//    private CountDownLatch latch = new CountDownLatch(1);
//
//    public CountDownLatch getLatch() {
//        return latch;
//    }
//
//    @KafkaListener(topics = "${kafka.topic}")
//    public void receive(TradeFile trade) {
//        System.out.println("received Trade file = '{}' "+trade.toString());
//        latch.countDown();
//    }

//    @KafkaListener(id = "consumer", topics = {"${kafka.topic}"} )
//    public void onMessage(ConsumerRecord<?, ?> record) {
//
//        System.out.println("Read Record is : " + record.value());
//        System.out.println("Read Key is : " + record.key());


//implements AcknowledgingMessageListener<String, String>
//    @Override
//    @KafkaListener(id = "consumer", topics = {"${kafka.topic}"} )
//    public void onMessage(ConsumerRecord<String, String> data,
//                          String acknowledgment) {
//        // TODO Auto-generated method stub
//        try{
//            System.out.println("Read Record is : " + data.value());
//            System.out.println("Offset is : " + data.offset());
//            System.out.println("Topic is : " + data.topic());
//            System.out.println("Partition is : " + data.partition());
//
//        }catch (Exception e ){
//            System.out.println("Push the messaged to Error Stream : " + e);
//        }




    //}
}
