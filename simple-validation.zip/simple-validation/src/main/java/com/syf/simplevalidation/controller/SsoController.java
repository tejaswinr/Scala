package com.syf.simplevalidation.controller;

import com.syf.simplevalidation.model.sso.Sso;
import com.syf.simplevalidation.repository.sso.SsoRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sso")
public class SsoController {

    private static final Logger logger = LogManager.getLogger(SsoController.class);

    @Autowired
    private SsoRepository ssoRepository;

    @GetMapping("/all")
    public List<Sso> getAll(){
        if(logger.isDebugEnabled()){
            logger.debug("Rest Find all Sso");
        }
        return ssoRepository.findAll();
    }

    @PostMapping("/new")
    public Sso insertOne(@RequestBody Sso sso){
        if(logger.isDebugEnabled()){
            logger.debug("Insert New Gcvid");
        }
        return ssoRepository.save(sso);
    }

    @GetMapping("/{sso}")
    public Sso getBySso (@PathVariable String sso){
        if(logger.isDebugEnabled()){
            logger.debug("Rest Find Gcvid By sso");
        }
        return ssoRepository.findBySso(sso);
    }
}
