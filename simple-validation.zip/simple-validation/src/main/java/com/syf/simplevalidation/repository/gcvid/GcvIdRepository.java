package com.syf.simplevalidation.repository.gcvid;

import com.syf.simplevalidation.model.gcvid.Gcvid;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GcvIdRepository extends JpaRepository<Gcvid, String> {

    Gcvid findBySso (String sso);
}
