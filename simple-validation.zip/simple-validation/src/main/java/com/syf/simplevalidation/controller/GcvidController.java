package com.syf.simplevalidation.controller;

import com.syf.simplevalidation.model.gcvid.Gcvid;
import com.syf.simplevalidation.repository.gcvid.GcvIdRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/gcvid")
public class GcvidController {

    private static final Logger logger = LogManager.getLogger(GcvidController.class);

    @Autowired
    private GcvIdRepository gcvIdRepository;

    @GetMapping("/all")
    public List<Gcvid> getAll(){

        if(logger.isDebugEnabled()){
            logger.debug("Rest Find all Gcvid");
        }
        return gcvIdRepository.findAll();
    }

    @PostMapping("/new")
    public Gcvid insertOne(@RequestBody Gcvid gcvid){
        if(logger.isDebugEnabled()){
            logger.debug("Rest Insert New Gcvid");
        }
        return gcvIdRepository.save(gcvid);
    }
}
