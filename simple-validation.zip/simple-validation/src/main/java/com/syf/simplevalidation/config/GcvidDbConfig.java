package com.syf.simplevalidation.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "gcvidEntityManagerFactory",
        transactionManagerRef = "gcvidTransactionManager",basePackages = "com.syf.simplevalidation.repository.gcvid")
public class GcvidDbConfig {

    @Bean(name = "gcvidDataSource")
    @ConfigurationProperties(prefix = "gcvid.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "gcvidEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(
            EntityManagerFactoryBuilder builder, @Qualifier("gcvidDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource).packages("com.syf.simplevalidation.model.gcvid").persistenceUnit("gcvid")
                .build();
    }

    @Bean(name = "gcvidTransactionManager")
    public PlatformTransactionManager transactionManager(
            @Qualifier("gcvidEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
}

