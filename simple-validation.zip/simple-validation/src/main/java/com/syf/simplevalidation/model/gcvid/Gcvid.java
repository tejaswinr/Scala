package com.syf.simplevalidation.model.gcvid;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gcvid")
public class Gcvid {

    @Id
    private String sso;

    private String gcvid;

    public String getSso() {
        return sso;
    }

    public void setSso(String sso) {
        this.sso = sso;
    }

    public String getGcvid() {
        return gcvid;
    }

    public void setGcvid(String gcvid) {
        this.gcvid = gcvid;
    }
}
