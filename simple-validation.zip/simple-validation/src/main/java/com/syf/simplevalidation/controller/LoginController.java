package com.syf.simplevalidation.controller;

import com.syf.simplevalidation.model.sso.Sso;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {

    private static final Logger logger = LogManager.getLogger(LoginController.class);

    @RequestMapping(path = "/login", method = RequestMethod.GET)
    public String loginPage(){
        if(logger.isDebugEnabled()){
            logger.debug("Login Page");
        }
        return "login";
    }

    @RequestMapping(path = "/after-Validation", method = RequestMethod.GET)
    @ResponseBody
    public String loginProcess (Sso sso){
        if(logger.isDebugEnabled()){
            logger.debug("Login Validated");
        }
       return "Successfully validated";
    }
}
