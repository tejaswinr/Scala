package com.syf.simplevalidation.controller;

import com.syf.simplevalidation.model.sso.Sso;
import com.syf.simplevalidation.repository.gcvid.GcvIdRepository;
import com.syf.simplevalidation.repository.sso.SsoRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class BasicRestController {

    private static final Logger logger = LogManager.getLogger(LoginController.class);

    @Autowired
    private SsoRepository ssoRepository;

    @Autowired
    private GcvIdRepository gcvIdRepository;

    @PostMapping("/login-validate")
    public String loginProcess (@RequestParam String sso, @RequestParam String pwd){


        if(logger.isDebugEnabled()){
            logger.debug("Login Validation");
        }


        if(sso != null && pwd != null){
            Sso sso1 = ssoRepository.findBySso(sso);
            if(sso1!= null){
                if(!(sso1.getPwd().equals(pwd))) {
                    logger.info("Password Match Unsuccessful");
                    return "Password Match Unsuccessful";
                }
                else{
                    if(null == gcvIdRepository.findBySso(sso)) {
                        logger.info("Invalid GCVID");
                        return "Invalid GCVID";
                    }
                }
            }else{
                logger.info("SSO Not Available");
                return "SSO Not Available";
            }
        }
        logger.info("Succesful Validataion");
        return "successful";
    }
}
