package com.syf.simplevalidation.repository.sso;

import com.syf.simplevalidation.model.sso.Sso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SsoRepository extends JpaRepository<Sso, String> {

    Sso findBySso(String sso);
}
