package com.att.reactchart.model;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.io.Serializable;

@Table(value = "error1")
public class Error1 implements Serializable {

    private static final long serialVersionUID = 1L;

    @PrimaryKey
    private Error1Key ek;

    private String date;
    private String time;
    private String module;
    private String exceptiontype;

    public Error1Key getEk() {
        return ek;
    }

    public void setEk(Error1Key ek) {
        this.ek = ek;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getExceptiontype() {
        return exceptiontype;
    }

    public void setExceptiontype(String exceptiontype) {
        this.exceptiontype = exceptiontype;
    }

    @Override
    public String toString() {
        return "Error1{" +
                "date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", module='" + module + '\'' +
                ", exceptiontype='" + exceptiontype + '\'' +
                '}';
    }
}
