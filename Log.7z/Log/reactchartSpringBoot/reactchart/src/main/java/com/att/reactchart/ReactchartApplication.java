package com.att.reactchart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactchartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactchartApplication.class, args);
	}
}
