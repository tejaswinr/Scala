package com.att.reactchart.repo;

import com.att.reactchart.model.Group;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;


public interface GroupRepository extends CassandraRepository<Group, String> {
}
