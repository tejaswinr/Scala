package com.att.reactchart.controller;

import com.att.reactchart.model.Error1;
import com.att.reactchart.model.Group;
import com.att.reactchart.repo.Error1Repository;
import com.att.reactchart.repo.GroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8082")
@RestController
@RequestMapping("/api")
public class ReactRestController {

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private Error1Repository error1Repository;
    private static final Logger logger = Logger.getLogger ( ReactRestController.class );

    @GetMapping("/groups")
    public List<Group> getAllGroup(){
        return groupRepository.findAll();
    }

    @GetMapping("/error1")
    public List<Error1> getAllError1(){
        return error1Repository.findAll();
    }
    @GetMapping("/exception/{num}")
    public String getException(@PathVariable("num") int num){
        for (int i = 1; i <= num; i++) {
            int test = (int)(Math.random() * 6);



            try {
                switch (test) {
                    case 0:
                        throw new IllegalStateException("Web.home.page");
                    case 1:
                        throw new FileNotFoundException("Web.register.page");
                    case 2:
                        throw new ClassCastException("Web.transcation.page");
                    case 3:
                        throw new ArrayIndexOutOfBoundsException("Web.userLogin.page");
                    case 4:
                        throw new SecurityException("Web.logout.page");
                    default:
                        throw new StringIndexOutOfBoundsException ("Web.Registration.page");
                }
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
            }

        }
        return "Exception rest";
    }
}
