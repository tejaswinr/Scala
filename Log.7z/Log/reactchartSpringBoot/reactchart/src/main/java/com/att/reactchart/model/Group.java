package com.att.reactchart.model;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.io.Serializable;

@Table(value = "group")
public class Group implements Serializable {

    private static final long serialVersionUID = 1L;

    @PrimaryKey
    private String module;

    private String numofexp;

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getNumofexp() {
        return numofexp;
    }

    public void setNumofexp(String numofexp) {
        this.numofexp = numofexp;
    }

    @Override
    public String toString() {
        return "group{" +
                "module='" + module + '\'' +
                ", numofexp='" + numofexp + '\'' +
                '}';
    }
}
