package com.att.reactchart.repo;

import com.att.reactchart.model.Error1Key;
import com.att.reactchart.model.Error1;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface Error1Repository extends CassandraRepository<Error1, Error1Key> {
}
