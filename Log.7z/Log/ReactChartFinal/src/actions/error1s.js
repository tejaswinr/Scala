import axios from '../axios/axios';

const _getError1s = (error1s) => ({
    type: 'GET_ERROR1S',
    error1s
});

export const getError1s = () => {
    return (dispatch) => {
        return axios.get('/error1').then(result => {
            const error1s = [];

            result.data.forEach(item => {
                error1s.push(item);
            });

            dispatch(_getError1s(error1s));
        });
    };
};

const _getGroups = (groups) => ({
    type: 'GET_GROUPS',
    groups
});

export const getGroups = () => {
    return (dispatch) => {
        return axios.get('groups').then(result => {
            const groups = [];

            result.data.forEach(item => {
                groups.push(item);
            });

            dispatch(_getGroups(groups));
        });
    };
};