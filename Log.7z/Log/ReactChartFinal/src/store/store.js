import { createStore, applyMiddleware } from "redux";
import error1s from '../reducers/error1s';
import thunk from 'redux-thunk';

export default () => {
    return createStore(error1s, applyMiddleware(thunk));
};