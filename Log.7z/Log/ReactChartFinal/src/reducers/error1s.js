const error1sReducerDefaultState = [];

export default (state = error1sReducerDefaultState, action) => {
    switch (action.type) {
        case 'GET_ERROR1S':
            console.log("Get Error1s");
            return action.error1s;
        case 'GET_GROUPS':
            console.log("Get Groups");
            return action.groups;
        default:
            console.log("Default error1s");
            return state;
    }
};
