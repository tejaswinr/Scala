import React from 'react';
import BarChartComponent from './BarChartComponent';

const DashBoard = () => (
    <div className='container__list'>
          <BarChartComponent/>
    </div>
);
export default DashBoard;
