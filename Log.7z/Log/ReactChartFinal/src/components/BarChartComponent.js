
import React, { Component } from 'react';
import { Bar } from 'react-chartjs-2';
import axios from '../axios/axios';

let count = 0;
export default class BarChartComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Data: this.getChartData()
    }
  }

  getChartData() {
    return axios.get('/groups').then(result => {
      const module = [];
      const numofexp = [];
      const background = [];

      result.data.forEach(item => {
        module.push(item.module);
        numofexp.push(item.numofexp);
        background.push(
          "#000000".replace(/0/g, function () {
            return (~~(Math.random() * 16)).toString(16)
          })
        );
      });
      this.setState({
        Data: {
          labels: module,
          datasets: [
            {
              data: numofexp,
              backgroundColor: background
            }
          ]
        }
      });
    })
  }

  componentDidMount() {
    this.interval = setInterval(() => {
      this.getChartData();
    }, 120000);
  }
  componentWillUnmount() {
    clearInterval(this.interval);
  }
  render() {
    return (
      <div className="App">
        <Bar
          data={this.state.Data}
          options={{
            maintainAspectRatio: true,
            legend: {
              display: false
            },
            scales: {
              yAxes: [{
                scaleLabel: {
                  display: true,
                  labelString: 'Errors',
                  fontSize: 22,
                  fontColor: 'black'
                }
              }],
              xAxes: [{
                scaleLabel: {
                  display: true,
                  labelString: 'Modules',
                  fontSize: 22,
                  fontColor: 'black'
                }
              }]
            }
          }} />
      </div>
    )
  }
}
