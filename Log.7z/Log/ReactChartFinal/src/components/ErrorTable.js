import React from 'react';
import Error1List from './Error1List';

const ErrorTable = () => (
    <div className='container__list'>
        <Error1List />
    </div>
);

export default ErrorTable;