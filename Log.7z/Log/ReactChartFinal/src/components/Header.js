import React from 'react';
import { NavLink } from 'react-router-dom';

const Header = () => (
    <header>
        <h2>Opus Log Analytica</h2>
        <div className='header__nav'>
            <NavLink to='/' activeClassName='activeNav' exact={true}>Module Vs Errors</NavLink>
            <NavLink to='/error' activeClassName='activeNav'>Error Details</NavLink>
        </div>
    </header>
);

export default Header;