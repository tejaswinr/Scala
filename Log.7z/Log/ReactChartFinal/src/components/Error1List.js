import React from 'react';
import { connect } from 'react-redux';
import Error1 from './Error1';

const Error1List = (props) => (
    <div>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Module</th>
                    <th>Exception Type</th>
                </tr>
            </thead>
            {props.error1s.map(error1 => {
                return (
                    <tbody key = {error1.time}>
                        <Error1 {...error1} />
                    </tbody>
                );
            })}
        </table>
    </div>
);

const mapStateToProps = (state) => {
    return {
        error1s: state
    };
}

export default connect(mapStateToProps)(Error1List);