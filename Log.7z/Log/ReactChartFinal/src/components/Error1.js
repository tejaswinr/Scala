import React from 'react';
import { connect } from 'react-redux';

const Error1 = ({ ak, date, time, module, exceptiontype }) => (
        <tr>
            <td>{date}</td>
            <td>{time}</td>
            <td>{module}</td>
            <td>{exceptiontype}</td>
        </tr>
);

export default connect()(Error1);