Now, we need to define properties for logging in log4j.properties inside resources
We also need html resolver to resolve the html file, for this we will use thymeleaf (there are other options like velocity)
can you run
,Its rendering
Now we will go with exception
Lets put in other place than C:// ok

got it, if you INFO or ERROR then debug code will not execute. No need to change code in production stage
ok