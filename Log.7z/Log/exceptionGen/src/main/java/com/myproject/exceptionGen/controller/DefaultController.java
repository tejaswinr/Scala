package com.myproject.exceptionGen.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.FileNotFoundException;

//Are you there,Yes
@Controller
@RequestMapping("/")
public class DefaultController {

    private static final Logger logger = Logger.getLogger ( DefaultController.class );

    @RequestMapping(method = RequestMethod.GET)
    public String home(){

        logger.debug ( "Home Page" );
        logger.error ( "This is just test for INFO" );
        return "index";
    }

    @RequestMapping(value = "/exception/{num}", method = RequestMethod.GET)
    public String exception(@PathVariable("num") int num){
        logger.debug ( "Exception trial " );

        try{

            if(num%2 == 0) {
                throw new FileNotFoundException ( "Web.home.page" );
            }else{
                throw new IllegalStateException ( "Web.register.page" );
            }

        }catch (FileNotFoundException ex){
            
            logger.error ( ex.getMessage (), ex );
        }catch (IllegalStateException ex){
            logger.error ( ex.getMessage (), ex );
        }
        return "exception";
    }
}
