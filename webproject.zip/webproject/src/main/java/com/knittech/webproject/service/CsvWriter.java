package com.knittech.webproject.service;

import org.springframework.stereotype.Service;

import java.io.*;

@Service
public class CsvWriter {
    public void csvWriter(String filename, String content) {
        try {
            File csvFile = new File(filename);
            FileOutputStream is = new FileOutputStream(csvFile, true);
            OutputStreamWriter osw = new OutputStreamWriter(is);
            Writer w = new BufferedWriter(osw);
            w.append(content);
            w.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

