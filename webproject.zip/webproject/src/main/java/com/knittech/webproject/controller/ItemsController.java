package com.knittech.webproject.controller;

import com.knittech.webproject.model.Items;
import com.knittech.webproject.service.CsvWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/")
public class ItemsController {

    @Autowired
    private CsvWriter csvWriter;

    public String index(){
        return "index";
    }

    @ResponseBody
    @RequestMapping("/add")
    public String addItems(Items items){
        // you can change y
        String filename="C:\\data1\\Items.csv";

        csvWriter.csvWriter(filename, items.toCsv());
        return "success";
    }
}
