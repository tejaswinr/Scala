package com.knittech.webproject.model;

public class Items {

    private String item;

    private float quantity;

    private float price;

    private float total;

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantiy) {
        this.quantity = quantiy;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public String toCsv() {
        return item +"," + price + "," + quantity + "," + total+"\n";
    }
}
