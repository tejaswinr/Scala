package com.citigroup.ewb.common.util;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

public class LongSerde  implements Serde<Long>  {
    private LongSerializer serializer = new LongSerializer();
    private LongDeserializer deserializer = new LongDeserializer();
	@Override
	public void close() {
		// TODO Auto-generated method stub
		serializer.close();
		deserializer.close();
	}

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		// TODO Auto-generated method stub
        serializer.configure(configs, isKey);
        deserializer.configure(configs, isKey);
	}

	@Override
	public Deserializer<Long> deserializer() {
		// TODO Auto-generated method stub
		return deserializer;
	}

	@Override
	public Serializer<Long> serializer() {
		// TODO Auto-generated method stub
		return serializer;
	}

}
