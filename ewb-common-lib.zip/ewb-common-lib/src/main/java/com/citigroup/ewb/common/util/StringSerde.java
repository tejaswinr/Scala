package com.citigroup.ewb.common.util;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

public class StringSerde implements Serde<String> {
    private StringSerializer serializer = new StringSerializer();
    private StringDeserializer deserializer = new StringDeserializer();

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        serializer.configure(configs, isKey);
        deserializer.configure(configs, isKey);
    }

    @Override
    public void close() {
        serializer.close();
        deserializer.close();
    }

    @Override
    public Serializer<String> serializer() {
        return serializer;
    }

    @Override
    public Deserializer<String> deserializer() {
        return deserializer;
    }

}
