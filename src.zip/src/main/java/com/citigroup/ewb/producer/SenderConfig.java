package com.citigroup.ewb.producer;


import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.serializer.AvroSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


@Configuration
public class SenderConfig {

    Logger logger = LogManager.getLogger(SenderConfig.class);

	private static final String prefix = "kafka.producer.";

    @Autowired
    private Environment evn;

    @Value("${bootstrap.servers:sd-ca1d-dc6f:9092}")
    private String bootstrapservers;

 @Value("${schema.registry.url:http://sd-ca1d-dc6f:8082}")
 private String schemaregistryurl;

    @Value("${kafka.producer.acks:all}")
    private String acks;

    @Value("${kafka.producer.retries:0}")
    private String retries;

    @Value("${kafka.producer.key.serializer}")
    private String keyserializer;

    @Value("${kafka.producer.value.serializer}")
    private String valueserializer;

    public Properties properties() {
        Properties properties = new Properties();

        properties.put("bootstrap.servers", bootstrapservers);
      properties.put("schema.registry.url", schemaregistryurl);
        properties.put("acks", acks);
        properties.put("retries", retries);
        properties.put("key.serializer", keyserializer);
        properties.put("value.serializer", valueserializer);

        return properties;
    }

}
