package com.citigroup.ewb.controllers;



import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.service.CoreService;
import com.citigroup.ewb.service.MyRunnable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import  com.citigroup.ewb.avro.Event;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@RestController
public class EwbController {



    @Autowired
    CoreService coreService;


    @RequestMapping(value="/publish")
    public String publish(@RequestParam("input") String noOfMessages) {


        ExecutorService es = Executors.newFixedThreadPool(10);

        ArrayList<Long> al = new ArrayList<Long>();



        Runnable worker = new MyRunnable(coreService);

        int n = Integer.parseInt(noOfMessages);

        long time1 = System.currentTimeMillis();
        System.out.println("time started "+time1);
        for(int i = 0; i < n ; i++){
            es.execute(worker);
        }

        long time2 = System.currentTimeMillis();
        //System.out.println("time completed "+time2);

        long time3 = time2-time1;

        System.out.println("time completed "+time3);


        System.out.println("List--->"+al);

        return "sucess";

//       System.out.println("transId ---  " + e.toString());
//        return e.toString();


    }

}
