package com.citigroup.ewb.service;


import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.producer.EwbCoreSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class CoreService {

    @Autowired
    EwbCoreSender ewbCoreSender;

    public String publish(Event event){
        String key= String.valueOf(event.getTRANSACTIONID());
        try {
            if (event != null) {
             ewbCoreSender.send(key, event);
            }
        }catch(Exception ex){
            ex.printStackTrace();
           return "unable to publish";
        }
        return "published with key " +key;
   }
}


