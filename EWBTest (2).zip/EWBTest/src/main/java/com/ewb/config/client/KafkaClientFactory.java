package com.ewb.config.client;

import com.ewb.event.adapter.EWBKafkaConsumer;
import com.ewb.event.adapter.EWBKafkaProducer;

public class KafkaClientFactory {

	public EWBKafkaProducer createProducer(KafkaClientConfig clientConfigs) {
		return null;
	}

	public EWBKafkaConsumer createConsumer(KafkaClientConfig clientConfig) {
		return null;
	}

}
