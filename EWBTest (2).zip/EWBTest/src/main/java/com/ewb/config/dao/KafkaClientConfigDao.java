package com.ewb.config.dao;

import java.util.List;

import com.ewb.config.client.KafkaClientConfig;

public class KafkaClientConfigDao {

	public List<KafkaClientConfig> getClientConfigs(String systemId) {
		return null;
	}
}
