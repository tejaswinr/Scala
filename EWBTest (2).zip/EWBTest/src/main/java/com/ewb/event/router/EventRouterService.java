package com.ewb.event.router;

public class EventRouterService implements Runnable {
	private EventRouter eventRouter;

	public void run() {

	}

	public void routeEvents() {

	}

}
