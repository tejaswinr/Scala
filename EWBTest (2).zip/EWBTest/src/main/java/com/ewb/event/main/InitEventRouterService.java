package com.ewb.event.main;

import com.ewb.config.client.CacheEventTypeKafkaClientMap;
import com.ewb.event.router.EventRouterFactory;

public class InitEventRouterService {
	private CacheEventTypeKafkaClientMap cache;
	private EventRouterFactory eventRouterFactory;

	public InitEventRouterService() {
		super();
	}

	public void intiateMessageRouterFactory() {

	}
}
