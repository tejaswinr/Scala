package com.ewb.event.entity;

public enum EventType {

	MOM_EXP,
	TC_EXP,
	ACC_EXP;
}
