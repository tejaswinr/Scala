package com.ewb.event.entity;

import java.util.Date;

public class KafkaMessage {

	private String messageId;
	private String sourceSystemId;
	private Date createdDateTime;
	private Event event;

}
