package com.ewb.event.adapter;

import com.ewb.event.entity.Event;
import com.ewb.event.entity.KafkaMessage;

public class KafkaMessageFactory {

	public KafkaMessage createKafkaMessage(Event event) {
		return null;
	}

	public Event retreiveEvent(KafkaMessage message) {
		return null;
	}

}
