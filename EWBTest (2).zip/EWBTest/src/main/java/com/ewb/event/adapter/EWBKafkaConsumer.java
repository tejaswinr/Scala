package com.ewb.event.adapter;

import java.util.concurrent.BlockingQueue;

import org.apache.kafka.clients.consumer.Consumer;

import com.ewb.event.entity.KafkaMessage;

public class EWBKafkaConsumer implements Runnable {

	private BlockingQueue<KafkaMessage> consumerQueue;
	private Consumer consumer;

	public void run() {

	}

	public KafkaMessage receiveFromKafka() {
		return null;
	}

}
