package com.ewb.event.adapter;

import com.ewb.event.entity.Event;

public interface EventListener {

	public void receiveEvent(Event event);
}
