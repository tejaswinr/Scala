package com.ewb.event.adapter;

import java.util.concurrent.BlockingQueue;

import org.apache.kafka.clients.producer.Producer;

import com.ewb.event.entity.KafkaMessage;

public class EWBKafkaProducer implements Runnable {
	private BlockingQueue<KafkaMessage> producerQueue;
	private Producer producer;

	public void run() {
	}

	private void sendToKafka(KafkaMessage message) {

	}
}
