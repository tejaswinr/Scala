package com.ewb.event.entity;

import java.io.Serializable;
import java.util.Date;

public class TradeException implements Serializable {

	private String id;
	private String stage;
	private String source;
	private String description;
	private String category;
	private Date aging;
	private Severity severity;
	private Assigne assigne;
	private Status status;
	private List<Comment> comments;
	
}
