package com.mydemo.teja.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "profile")
public class Profile {
//now if your class name is same to table in database you neednot define @table, but we will do it here

	@Id
	//ID for primary key,ok
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// this for auto increment
	@Column(name = "id")
	//no need if same as column in db, also as db has column naming as sth_sth and in java we use sthSth, 
	// in that case if both are similar then no need to define column, got it?
	// for eg we may write user_name in db and similarly in Java we use userName in this case also column defination is
	//not needed. Capital N , ok got it
	//do you know how to insert getter and setter ?
	//by creating pojos
	// Right click> source>generate Getter and setters
	// now we will use spring data for operations like finding inserting and others
	
	private Integer id;
	
	//same not required column def
	private String name;
	private String address;
	private String phone;
	private int age;
	
	//lets create a constructor
	
	public Profile () {
		
	}
	
	//as id is generated automatically, no need of it. Also, when we create a custom defined constructor we need
	//to hard code for constructor withoout parameters
	public Profile(String name, String address, String phone, int age) {
		super();
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.age = age;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	
}
