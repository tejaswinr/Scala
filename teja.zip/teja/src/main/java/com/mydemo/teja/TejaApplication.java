package com.mydemo.teja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TejaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TejaApplication.class, args);
	}
}


