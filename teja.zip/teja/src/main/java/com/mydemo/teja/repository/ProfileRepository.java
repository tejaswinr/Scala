package com.mydemo.teja.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mydemo.teja.entity.Profile;

//. do you know repository?
//is it to define db details?
// Basically all database operations CRUD are done in repository
//while in service layer, we do buisness logic , like some calculations on data or data cleaning etc
//got??yes<T, Id> T for class , ID for type of primary key or id, in our case Profile and Integer
public interface ProfileRepository extends JpaRepository<Profile, Integer>{

	//no need of any thing as spring data will handle everything, later if we require some custom query we can do it, later? 
	//got?yes Now, we will define controller, port problem, its working
	//can we put the data to profile table
	//we will do it now, using POST method and then again check get, Ok?yes
}
