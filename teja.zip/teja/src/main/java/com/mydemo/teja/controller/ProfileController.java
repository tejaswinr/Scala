package com.mydemo.teja.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mydemo.teja.entity.Profile;
import com.mydemo.teja.repository.ProfileRepository;

@RestController
public class ProfileController {
//as we are building Rest api, we will use RESTCONTROLLER annotation
	@Autowired
	private ProfileRepository profileRepository;
	
	// Instead of Autowired for dependency Injection, we can use constructor as well, Do you want to see it?
	//show it if you can
	// no need to annote autowired if we do this, and this is recommended but most people use Autowired/Resource and even Inject(Not sure about inject)
	//public ProfileController(ProfileRepository profileRepository) {
	//	this.profileRepository = profileRepository;
	//}
	
	//ok first we will go with get, ready?yes
			
	//Instead of GetMapping, RequestMapping can also be used. Lets test this get
	@GetMapping("/list")
	public List<Profile> getAll(){
		return profileRepository.findAll();
	}
	
	
	//post cant be tested from browser/ so we will use postman .yes
	//we need to send json object so got to body in postman
	@PostMapping("/newprof")
	public Profile newProfile (@RequestBody Profile profile) {
		return profileRepository.save(profile);
	}
	
	//now we will use Request mapping instead of get or post to give you idea how to use it? OK? yes
	//we will now retrieve profile based on id
	//intellij is good here as it gives suggestions.
	
	@RequestMapping(value = "/list/{id}", method = RequestMethod.GET)
	public Profile getProfileById (@PathVariable int id) {
		return profileRepository.findById(id).get();
	}
	//Any Question?no am good
	// In ase like list/3 there was error shown, there is a practice to write custom ExceptionNot, can we keep the exception?
	//Yes, we can, do you want to write custom exception handling code /li
	//ok more 10 mins and we will go to junit test cases?	ok
	
	//update and delete using PUT and DELETE
	//as you can see here is an exception, we will discuss about it later
	//When we defined db schema I think we had set column value to be NOT NULL for every column, that might be the cause.
	//we can change schema and test? It will work for sure, you need not to worry.,ok
	//delete also working.
	//yes
	
	@PutMapping("/prof/{id}")
	public Profile updateProfileById (@PathVariable int id, @RequestBody Profile profile) {
		// here we need to use some logic, first we will find the profile using id and then only update it.
		//also Request is required so we add it as param
		Profile profileToUpdate = profileRepository.findById(id).get();
		System.out.println(profile.getName());
		profileToUpdate.setName(profile.getName());
		profileToUpdate.setAge(profile.getAge());
		profileToUpdate.setAddress(profile.getAddress());
		profileToUpdate.setPhone(profile.getPhone());
		
		profileToUpdate = profileRepository.save(profileToUpdate);
		return profileToUpdate;
	}
	
	@DeleteMapping ( "/prof/{id}")
	public void deleteById (@PathVariable int id) {
		Profile profileToDelete = profileRepository.findById(id).get();
		profileRepository.delete(profileToDelete);
	}
}
