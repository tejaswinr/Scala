package com.mydemo.teja.controller;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.mydemo.teja.entity.Profile;
import com.mydemo.teja.repository.ProfileRepository;

@RunWith(MockitoJUnitRunner.class)
public class ProfileControllerTest {

	@Mock
	ProfileRepository profileRepository;
	
	//can you press cntr + space
	@InjectMocks
	ProfileController profileController;
	
	//beforeclass and after class will work before execution and after execution of this class
	//beforeclass ==> we will create profile and in afterclass==> destroy it or assign null value to it
	//both are static class so to create user in before class we need static profile sorry defined
	static Profile profile;
	
	@BeforeClass
	public static void init() {
		System.out.println("Before created");
		profile = new Profile("testname", "testaddress","testphone", 20);
	}
	
	@AfterClass
	public static void clean() {
		System.out.println("After destroy");
		profile = null;
	}
	
	//now lets write test cases, we will start with save/ remember expected with actual
	@Test
	public void saveProfileTest() {
		//this is db oberation and we expect our controller to return same result, isn,t it?may be. Yes 
		//what controller does is post user to db and returns object profile that is saved in db.
		//so this is expected one, this was easy way for u to understand but the practice is this
		Mockito.when(profileRepository.save(profile)).thenReturn(profile);
		Profile actualProfile = profileController.newProfile(profile);
		
		assertEquals (profile, actualProfile);
	}
	
	// we do it similarly for others, and most importantly rest apis are tested using MockWebMvc but initially we will do
	//these and later we can jump there
	//ok,will stop here Its totally new to me. 
	//i will understand and I will get back to you/.den we will start for other things ok?
	//okay but lets complete the save one., ok
	//if you want i can send you a simple program with basic example to help you understand j
//	jUnit, a basic one with explanations as comments and then we can get back here at this point agian.
	//sure please share it.
	//i will prepare it today and send it to you tomoroow.
	//How much hours did we spent yesterday, bro?>
	//4 i think. correct me if i am wrong. I don't think we did 4 yesterday because 4 is a lot time.
	//2.5 hours might be? is it? round up to 3 and 
	//share example Okaytoda bro.
	
	//okay, i will get ready for office, bro you will need to accept manual time in upwork for yesterday, because i for
	//forgot to start tracker, for todays its tracked.//ok i will try to creat and i will assign you the project
	// no no we need not to assign project, we had created one before i will add manual 3 hours there you need to accept it
	//ok 
	//add todays 1hour also total 4. For today's upworks time traking tool showed 40 mins so it will show it in
	//your dashboard, i will just add 3 hours manual for yesterday? ok?ok.bye have a great day.you too have a greatt day bye 	

}
