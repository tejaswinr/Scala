package clickstream

import org.apache.hadoop.hive.ql.exec.spark.session.SparkSession
import org.apache.spark
import org.apache.spark.{SparkConf, SparkContext}


object sparktocassandra extends App {

}