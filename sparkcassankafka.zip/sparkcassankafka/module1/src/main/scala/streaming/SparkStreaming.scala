package streaming

import config.Settings
import domain.Activity
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Duration, Seconds, StreamingContext}
import utils.SparkUtils.{getSQLContext, getSparkContext}
import org.apache.spark.streaming.kafka._
import kafka.serializer.StringDecoder
import org.apache.spark
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SQLContext
import org.apache.spark.storage.StorageLevel

import com.datastax.spark.connector._
import com.datastax.spark.connector.streaming._

object SparkStreaming {
  def main(args: Array[String]): Unit = {

    val sconf = new SparkConf().setMaster("local[2]").setAppName("Testing Spark job")
    val sc = new SparkContext(sconf)
    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._
    val batchDuration = Seconds(4)
    val ssc = new StreamingContext(sc, batchDuration)
    ssc.checkpoint("checkpoint")
    val topic = "weblogs-text"
    val kafkaDirectParams = Map(
      "group.id" -> "lambda",
      "zookeeper.connect" -> "localhost:2181",
      "auto.offset.reset" -> "largest"
    )

    val kstream = KafkaUtils.
      createStream[String, String, StringDecoder, StringDecoder](ssc, kafkaDirectParams, Map(topic -> 1),
      StorageLevel.MEMORY_AND_DISK).map(_._2)
    val activityStream = kstream.transform(input => {
      val inputRdd = input.flatMap(line => {
        val record = line.split("\\t")
        val MS_IN_HOUR = 1000 * 60 * 60
        if (record.length == 7)
          Some(Activity(record(0).toLong / MS_IN_HOUR * MS_IN_HOUR, record(1), record(2), record(3), record(4), record(5), record(6)))
        else
          None
      })
      val df = inputRdd.toDF()
      df.show(false)
      df.registerTempTable("activity")
      sqlContext.cacheTable("activity")
      inputRdd
    })
    activityStream.foreachRDD(x=>{x.saveToCassandra("s_data", "stream_product")})
    activityStream.print()
    ssc.start()
    ssc.awaitTermination()
  }

}
