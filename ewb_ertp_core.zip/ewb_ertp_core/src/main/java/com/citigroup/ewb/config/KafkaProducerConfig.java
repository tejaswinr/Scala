package com.citigroup.ewb.config;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.Properties;

/**
 * The configuration is for a KafkaProducer used by AvroEventProducer.
 * A sample is as below:
 * kafka.producer.acks=all
 * kafka.producer.retries=0
 * kafka.producer.key.serializer=io.confluent.kafka.serializers.KafkaAvroSerializer
 * kafka.producer.value.serializer=io.confluent.kafka.serializers.KafkaAvroSerializer
 * 
 * @author zh22901
 * @see AvroEventProducer
 */
@Configuration
public class KafkaProducerConfig {
	
	Logger logger = LogManager.getLogger(KafkaProducerConfig.class);
	
//	private static final String prefix = "kafka.producer.";
	
	@Autowired
	private Environment evn;
	
	@Value("${bootstrap.servers:sd-ca1d-dc6f:9092}")
	private String bootstrapservers;	

	@Value("${schema.registry.url:http://sd-ca1d-dc6f:8082}")
	private String schemaregistryurl;
	
	@Value("${kafka.producer.acks:all}")
	private String acks;
	
	@Value("${kafka.producer.retries:0}")
	private String retries;
	
	@Value("${kafka.producer.key.serializer:org.apache.kafka.common.serialization.StringSerializer}")
	private String keyserializer;

	@Value("${kafka.producer.value.serializer:io.confluent.kafka.serializers.KafkaAvroSerializer}")
	private String valueserializer;

	public Properties properties() {
	    Properties properties = new Properties();

	    properties.put("bootstrap.servers", bootstrapservers);
	    properties.put("schema.registry.url", schemaregistryurl);
	    properties.put("acks", acks);
	    properties.put("retries", retries);
	    properties.put("key.serializer", keyserializer);
	    properties.put("value.serializer", valueserializer);
	    
	    return properties;
	}

}
