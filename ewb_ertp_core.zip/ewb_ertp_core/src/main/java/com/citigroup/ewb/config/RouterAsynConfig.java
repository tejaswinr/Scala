package com.citigroup.ewb.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class RouterAsynConfig {

	@Autowired
	private Environment evn;
	
	@Value("${kafka.router.streaming.core:2}")
	private Integer corenumber;

	public Integer getCoreNumber() {
		return this.corenumber;
	}
}
