package com.citigroup.ewb.domain;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 
 * @author zh22901
 *
 */
public interface ProcessService {
	/**
	 * real time streaming process
	 * @return number of records processed in total
	 */
    CompletableFuture<AtomicLong> process();
	 /**
	  * stop processing
	  */
     void stop();
}
