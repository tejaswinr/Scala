package com.citigroup.ewb.controllers;


import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.model.EventJson;
import com.citigroup.ewb.service.CoreService;
import com.citigroup.ewb.service.MyRunnable;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@RestController
public class EwbController {



    @Autowired
    CoreService coreService;


    @RequestMapping(value="/publish")
    public String publish(@RequestParam("input") String noOfMessages) {

//        if(reqParam=  jason  is not null )_{
//           CoreService.publish(Event)
//        }

        ExecutorService es = Executors.newFixedThreadPool(10);

        ArrayList<Long> al = new ArrayList<Long>();



        Runnable worker = new MyRunnable(coreService);

        int n = Integer.parseInt(noOfMessages);

        long time1 = System.currentTimeMillis();
        System.out.println("time started "+time1);
        for(int i = 0; i < n ; i++){
            es.execute(worker);
        }

        long time2 = System.currentTimeMillis();
        //System.out.println("time completed "+time2);

        long time3 = time2-time1;

        System.out.println("time completed "+time3);


        System.out.println("List--->"+al);

        return "success";

//       System.out.println("transId ---  " + e.toString());
//        return e.toString();


    }

    @RequestMapping(value="/publish/firmCode")
    public String publishAvro(@RequestParam("firmCode") String firmCode) {

//        if(reqParam=  jason  is not null )_{
//           CoreService.publish(Event)
//        }
        if(StringUtils.isNotEmpty( firmCode )) {
            firmCode = firmCode.trim();
            if (validFirmCode( firmCode )) {
                Event e = EventGenerator.getNext();
                e.setFirmCode( firmCode );
                coreService.publish( e );
                return "published data : " + e.toString();
            } else {

                return "Invalid firmCode, please give correct firmCode";
            }
        }else{
            return "please give firmCode in request";
        }

    }



    @RequestMapping(value="/publish/firmCode/exceptionCategory")
    public String publishFirmErrorCategory(@RequestParam("firmCode") String firmCode,@RequestParam("exceptionCategory") String exceptionCategory) {

//        if(reqParam=  jason  is not null )_{
//           CoreService.publish(Event)
//        }
        if(StringUtils.isNotEmpty( firmCode ) && StringUtils.isNotEmpty( exceptionCategory )) {
            firmCode = firmCode.trim();
            exceptionCategory = exceptionCategory.trim();
            if (validFirmCode( firmCode )) {
                Event e = EventGenerator.getNext();
                e.setFirmCode( firmCode );
                e.setExceptionCategory( exceptionCategory );
                coreService.publish( e );
                return "published data : " + e.toString();
            } else {

                return "Invalid firmCode, please give correct firmCode";
            }
        }else{
            return "please give firmCode and exception category in request";
        }

    }


    @RequestMapping(value="/publish/json", method = RequestMethod.POST)
    public String publisJSONData(@RequestBody EventJson eventJson) {

        if (eventJson != null){

            Event event = new Event();
            event.setExceptionCategory( eventJson.getExceptionCategory() );
            event.setTransactionId(eventJson.getTransactionId());
            event.setQuantity(eventJson.getQuantity());
            event.setCreatedDate(eventJson.getCreatedDate());
            event.setBatchId(eventJson.getBatchId());
            event.setSource(eventJson.getSource());
            event.setCustodianAccount(eventJson.getCustodianAccount());
            event.setAssetClass(eventJson.getAssetClass());
            event.setAllocationId( eventJson.getAllocationId() );
            event.setCreatedBy( eventJson.getCreatedBy() );
            event.setFirmCode( eventJson.getFirmCode() );
            event.setRemediationStep( eventJson.getRemediationStep() );
            event.setPortfolioCode( eventJson.getPortfolioCode() );
            event.setExecutingBroker( eventJson.getExecutingBroker() );
            event.setFilePath( eventJson.getFilePath() );
            event.setAssetTypeCode(eventJson.getAssetTypeCode());
            event.setErrorDescription(eventJson.getErrorDescription());
            event.setUpdatedDate(eventJson.getUpdatedDate());
            event.setErrorCategory(eventJson.getErrorCategory());
            event.setFileType(eventJson.getFileType());
            event.setBlockExternalReferenceId(eventJson.getBlockExternalReferenceId());
            event.setCoreSystem(eventJson.getCoreSystem());
            event.setProfileKey( eventJson.getProfileKey() );
            event.setProfile( eventJson.getProfile());
            event.setProfileTime( eventJson.getProfileTime() );

            coreService.publish( event );
            return "sucess " ;


        }else{
            return "please request in json";
        }

    }

    public boolean validFirmCode(String firmCode) {

        boolean flag = false;


        String[] firms = {"OMGI","KAMES","SLI"};
        List<String> firmList = new ArrayList<String>(Arrays.asList(firms));


        System.out.println(" firmCodes :"+firmList);
        if(firmList.contains( firmCode )){
            flag = true;
        }

        return flag;

    }

}
