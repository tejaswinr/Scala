package com.citigroup.ewb.producer;

import com.citigroup.ewb.avro.Event;
        import org.apache.kafka.clients.producer.KafkaProducer;
        import org.apache.kafka.clients.producer.Producer;
        import org.apache.kafka.clients.producer.ProducerRecord;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.beans.factory.annotation.Value;
        import org.springframework.kafka.core.KafkaTemplate;
        import org.springframework.stereotype.Component;

        import java.util.Properties;


@Component
public class EwbCoreSender {

    @Autowired
    SenderConfig config;

    private static final Logger LOGGER = LoggerFactory.getLogger(EwbCoreSender.class);

    @Value("${kafka.core.topic}")
    private String avroTopic;

//  @Autowired
//  private KafkaTemplate<String, Event> kafkaTemplate;

    public void send(String key, Event event) {
        LOGGER.info("sending tradeFile='{}' ", event.toString());
        Properties props = config.properties();
        Producer<String, Event> producer = new KafkaProducer<String, Event>(props);
        ProducerRecord<String, Event> record = new ProducerRecord<String, Event>(avroTopic, key,event);

        producer.send(record);
         LOGGER.info("Published record-------"+record);
        //kafkaTemplate.send(avroTopic, key,event);
    }

//    public void send(String key, String) {
//
//    }
}
//  Producer<String, String> producer = new KafkaProducer<String, String>(props);
//  ProducerRecord<String, String> record = new ProducerRecord<String, String>(avroTopic, key,"Hello");