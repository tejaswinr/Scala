package com.citigroup.ewb.consumer;


import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.serializer.AvroDeserializer;
import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;


import java.util.HashMap;
import java.util.Map;
import java.util.Properties;



@Configuration
@EnableKafka
public class ReceiverConfig {

//  Logger logger = LogManager.getLogger(ReceiverConfig.class);
//
//  @Autowired
//  private Environment evn;
//
//  @Value("${kafka.router.core.topic:coresystem}")
//  public String coretopic;
//
//  @Value("${kafka.router.streaming.application.id:ewb-router}")
//  public String applicationid;
//
//  @Value("${bootstrap.servers:sd-9a28-ab9d:9092}")
//  public String bootstrapservers;
//
//  @Value("${kafka.router.streaming.client.id:router}")
//  public String clientid;
//
//  @Value("${schema.registry.url:http://sd-9a28-ab9d:8081}")
//  public String schemaregistryurl;
//
//  @Value("${kafka.router.streaming.default.key.serde:org.apache.kafka.common.serialization.Serdes.StringSerde}")
//  public String defaultkeyserde;
//
//  @Value("${kafka.router.streaming.default.value.serde:com.citigroup.ewb.common.util.SpecificAvroSerde}")
//  public String defaultvalueserde;
//
//  @Value("${kafka.router.streaming.state.dir:/home/zh22901/workspace}")
//  public String statedir;
//
//  @Value("${kafka.router.streaming.auto.offset.reset:earliest}")
//  public String autooffsetreset;
//
//  @Value("${kafka.router.streaming.commit.interval.ms:1000}")
//  public String commitintervalms;
//
//  public Properties properties() {
//    Properties properties = new Properties();
//
//    properties.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationid);
//    properties.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapservers);
//    properties.put(StreamsConfig.CLIENT_ID_CONFIG, clientid);
//    properties.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaregistryurl);
//    properties.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, defaultkeyserde);
//    properties.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, defaultvalueserde);
//    properties.put(StreamsConfig.STATE_DIR_CONFIG, statedir);
//    properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autooffsetreset);
//    properties.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, commitintervalms);
//
//    return properties;
//  }
//
//  private void setProperty(String dstkey, String sourcekey, Properties source, Properties p) {
//    if (source.getProperty(sourcekey) != null) {
//      p.put(dstkey, source.getProperty(sourcekey));
//      logger.info(sourcekey + ": " + source.getProperty(sourcekey));
//    }
//  }
//
//  @Bean
//  @ConfigurationProperties(prefix = "kafka.router")
//  public BasicRouterMapInterceptor interceptor() {
//    return new BasicRouterMapInterceptor();
//  }
//
//  public static class BasicRouterMapInterceptor {
//
//    private Map<String, String> processortopics = new HashMap<String, String>();
//
//    public Map<String, String> getProcessortopics() {
//      return this.processortopics;
//    }
//  }

}
