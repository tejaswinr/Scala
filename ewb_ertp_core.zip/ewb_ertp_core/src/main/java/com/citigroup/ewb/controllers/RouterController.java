package com.citigroup.ewb.controllers;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventAvroConverter;
import com.citigroup.ewb.common.util.EventGenerator;
import com.citigroup.ewb.common.util.EventTransfer;
import com.citigroup.ewb.domain.AvroEventProducer;
import com.citigroup.ewb.domain.ProcessService;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Zhi Huang
 *
 */

@Configuration
@EnableAutoConfiguration
@EnableConfigurationProperties
@RestController
public class RouterController {
	
	private static final Logger logger = LogManager.getLogger(RouterController.class);
	
    @Autowired
    AvroEventProducer producer;
    
	@Value("${kafka.router.incoming.topic:coresystem}")
	private String kafkaRouterIncomingTopic;
 
	@Autowired 
	private ProcessService processService;
	
	
    @RequestMapping(value = "/ewb/getEventJasonSample", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) 
    public @ResponseBody Map  getEventJasonSample() {
    	Event e = EventGenerator.getNext();
    	
    	return EventAvroConverter.toMap(e);
    }
    
    @RequestMapping(value = "/ewb/getEventSample", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) 
    public @ResponseBody EventTransfer  getEventSample() {
    	Event e = EventGenerator.getNext();
    	ByteBuffer bb = null;
    	try {
    		bb = e.toByteBuffer();
    	} catch(Exception ex) {
    		ex.printStackTrace();
    		logger.error(ex.getMessage());
    		return null;
    	}
//    	byte[] bytes = bb.array();
        
    	byte[] bytes = new byte[bb.remaining()];
        bb.get(bytes, 0, bytes.length);
        
    	EventTransfer et = new EventTransfer();
    	et.wrapEvent(bytes);
    	return et;
    	
    }
    
    
    @RequestMapping(value = "/ewb/eventProcess", method=RequestMethod.POST) 
    public @ResponseBody RecordMetadata eventProcess(@RequestBody EventTransfer et) {
    	RecordMetadata rm = null;
    	try {
    		Event event = et.restoreEvent();
    		rm = this.producer.produce(event, kafkaRouterIncomingTopic);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    	}
    	return rm;
    }
    
    @RequestMapping(value = "/ewb/jasonEventProcess", method=RequestMethod.POST) 
    public @ResponseBody RecordMetadata eventProcess(@RequestBody Map em) {
    	Event event = EventAvroConverter.mapToEvent(em);
    	RecordMetadata rm = null;
    	try {
    		System.out.print(event.toString());
    		rm = this.producer.produce(event, kafkaRouterIncomingTopic);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    	}
    	return rm;
    }   
    
    @RequestMapping(value = "/ewb/startRouting", method = RequestMethod.GET) 
    public ResponseEntity<Map<String, String>> startRouting() { 
    	processService.process(); 
    	Map<String, String> response = new HashMap<>(); 
        response.put("message", "Request is under process"); 
        return new ResponseEntity<>(response, HttpStatus.OK); 
    } 

}
