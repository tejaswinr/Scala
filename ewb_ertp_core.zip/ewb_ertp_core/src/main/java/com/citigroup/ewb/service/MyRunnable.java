package com.citigroup.ewb.service;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.common.util.EventGenerator;

import java.util.ArrayList;
import java.util.List;

public class MyRunnable implements  Runnable {

    CoreService coreService;

 //   List<Long> keys ;

   // Event event;


    public MyRunnable(CoreService coreService) {

        this.coreService = coreService;
        //this.keys = keys;
        //this.event = event;
    }

    public void run(){

       Event e= EventGenerator.getNext();

//        System.out.println("in run method");
//        System.out.println(e.getTRANSACTIONID());

    System.out.println("Published record-------"+e.toString());
        System.out.println("profiletime-------"+e.getProfileTime());
        System.out.println("profile-------"+e.getProfile());
        coreService.publish(e);
       // keys.add(e.getTRANSACTIONID());

    }
}
