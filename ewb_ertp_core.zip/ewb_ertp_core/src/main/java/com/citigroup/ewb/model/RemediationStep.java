package com.citigroup.ewb.model;

public class RemediationStep {

    public CharSequence getCustodianAccount() {
        return custodianAccount;
    }

    public void setCustodianAccount(CharSequence custodianAccount) {
        this.custodianAccount = custodianAccount;
    }

    private CharSequence custodianAccount;
}
