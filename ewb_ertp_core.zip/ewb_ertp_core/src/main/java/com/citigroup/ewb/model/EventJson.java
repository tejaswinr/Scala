package com.citigroup.ewb.model;

import com.citigroup.ewb.avro.RemediationStep;

public class EventJson {

    public long transactionId;

    public int quantity;

    public long createdDate;

    public long batchId;

    public CharSequence source;

    public CharSequence custodianAccount;

    public CharSequence assetClass;

    public CharSequence allocationId;

    public CharSequence createdBy;

    public CharSequence firmCode;

    public RemediationStep remediationStep;

    public CharSequence portfolioCode;

    public CharSequence executingBroker;

    public CharSequence filePath;

    public CharSequence assetTypeCode;

    public CharSequence errorDescription;

    public long updatedDate;

    public CharSequence exceptionCategory;

    public CharSequence errorCategory;

    public CharSequence fileType;

    public CharSequence blockExternalReferenceId;

    public CharSequence coreSystem;

    public CharSequence profileKey;

    public long profileTime;

    public CharSequence profile;

    public Long getTransactionId() {
        return this.transactionId;
    }

    public void setTransactionId(Long value) {
        this.transactionId = value.longValue();
    }

    public Integer getQuantity() {
        return this.quantity;
    }

    public void setQuantity(Integer value) {
        this.quantity = value.intValue();
    }

    public Long getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Long value) {
        this.createdDate = value.longValue();
    }

    public Long getBatchId() {
        return this.batchId;
    }

    public void setBatchId(Long value) {
        this.batchId = value.longValue();
    }

    public CharSequence getSource() {
        return this.source;
    }

    public void setSource(CharSequence value) {
        this.source = value;
    }

    public CharSequence getCustodianAccount() {
        return this.custodianAccount;
    }

    public void setCustodianAccount(CharSequence value) {
        this.custodianAccount = value;
    }

    public CharSequence getAssetClass() {
        return this.assetClass;
    }

    public void setAssetClass(CharSequence value) {
        this.assetClass = value;
    }

    public CharSequence getAllocationId() {
        return this.allocationId;
    }

    public void setAllocationId(CharSequence value) {
        this.allocationId = value;
    }

    public CharSequence getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(CharSequence value) {
        this.createdBy = value;
    }

    public CharSequence getFirmCode() {
        return this.firmCode;
    }

    public void setFirmCode(CharSequence value) {
        this.firmCode = value;
    }

    public RemediationStep getRemediationStep() {
        return this.remediationStep;
    }

    public void setRemediationStep(RemediationStep remediationStep) {
        this.remediationStep = remediationStep;
    }

    public CharSequence getPortfolioCode() {
        return this.portfolioCode;
    }

    public void setPortfolioCode(CharSequence value) {
        this.portfolioCode = value;
    }

    public CharSequence getExecutingBroker() {
        return this.executingBroker;
    }

    public void setExecutingBroker(CharSequence value) {
        this.executingBroker = value;
    }

    public CharSequence getFilePath() {
        return this.filePath;
    }

    public void setFilePath(CharSequence value) {
        this.filePath = value;
    }

    public CharSequence getAssetTypeCode() {
        return this.assetTypeCode;
    }

    public void setAssetTypeCode(CharSequence value) {
        this.assetTypeCode = value;
    }

    public CharSequence getErrorDescription() {
        return this.errorDescription;
    }

    public void setErrorDescription(CharSequence value) {
        this.errorDescription = value;
    }

    public Long getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(Long value) {
        this.updatedDate = value.longValue();
    }

    public CharSequence getExceptionCategory() {
        return this.exceptionCategory;
    }

    public void setExceptionCategory(CharSequence value) {
        this.exceptionCategory = value;
    }

    public CharSequence getErrorCategory() {
        return this.errorCategory;
    }

    public void setErrorCategory(CharSequence value) {
        this.errorCategory = value;
    }

    public CharSequence getFileType() {
        return this.fileType;
    }

    public void setFileType(CharSequence value) {
        this.fileType = value;
    }

    public CharSequence getBlockExternalReferenceId() {
        return this.blockExternalReferenceId;
    }

    public void setBlockExternalReferenceId(CharSequence value) {
        this.blockExternalReferenceId = value;
    }

    public CharSequence getCoreSystem() {
        return this.coreSystem;
    }

    public void setCoreSystem(CharSequence value) {
        this.coreSystem = value;
    }

    public CharSequence getProfileKey() {
        return this.profileKey;
    }

    public void setProfileKey(CharSequence value) {
        this.profileKey = value;
    }

    public Long getProfileTime() {
        return this.profileTime;
    }

    public void setProfileTime(Long value) {
        this.profileTime = value.longValue();
    }

    public CharSequence getProfile() {
        return this.profile;
    }

    public void setProfile(CharSequence value) {
        this.profile = value;
    }
////
    //


}
