package com.citigroup.ewb.domain;

import com.citigroup.ewb.avro.Event;
import com.citigroup.ewb.config.KafkaRouterStreamingConfig;
import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.ForeachAction;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Predicate;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class EventKafkaStream {
	
	static final String TRADEEXCEPTION_EVENT = "TradeExceptionEvent";
	
	@Autowired
    KafkaRouterStreamingConfig config;
	
	KafkaStreams kafkaStreams;
	static AtomicLong totalProcessedEvents = new AtomicLong(0L);
	
	Serde stringSerde;// = Serdes.String();
    Serde eventSerde;// = Serdes.serdeFrom(Event.class);

    public static AtomicLong getTotalProcessedEvents() {
    	return totalProcessedEvents;
    }
	
	/**
	 * @startuml
	 * start
	 * :new StreamsBuilder;
	 * :build source stream(core system topic);
	 * :config.getProcessorTopics();
	 * while(more processorname available)
	 * :next processorname;
	 * :find topic;
	 * :configure processing topology for current topic&processor;
	 * end while
	 * stop
	 * @enduml
	 */
	/**
	 * Define the processing topology
	 * @return
	 */
	public KafkaStreams buildEventStreams() {

	    final StreamsBuilder builder = new StreamsBuilder();
	    // read the source stream
	    final KStream<String, Event> events = builder.stream(config.coretopic);
	    Map<String, String> processors = config.interceptor().getProcessortopics();

	    System.out.print("\r\nrouter map: " + processors.toString());

	    Thread.currentThread().setContextClassLoader(null);
	    
	    String eventserdename = config.properties().getProperty(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG);
	    System.out.print("\r\nevent serde: " + eventserdename);

	    String stringserdename = config.properties().getProperty(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG);
	    System.out.print("\r\nkey serde: " + stringserdename);

	    try {
			this.stringSerde = (Serde) Class.forName(stringserdename).newInstance();
			this.eventSerde = (Serde) Class.forName(eventserdename).newInstance();
			
			Map<String, String> props = new HashMap<>();
			props.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, config.schemaregistryurl);
			stringSerde.configure(props, true);
			eventSerde.configure(props, false);
			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    for (String processorname : processors.keySet() ) {
	    	String topicname = processors.get(processorname);
	    	this.configureProcess(processorname, topicname, events);
	    }
	    
	    return new KafkaStreams(builder.build(), config.properties());		
	}
	
	/**
	 * @startuml
	 * start
	 * :get key SerDe and value SerDe;
	 * :configure lambda expression to filter out events;
	 * :filter out events with lambda expression;
	 * :routes events to its topic with proper key SerDe and value SerDe;
	 * end
	 * @enduml
	 */
	/**
	 * configure real time streaming process per topic per processor
	 * @param processorname
	 * @param topicname
	 * @param events
	 */
	public void configureProcess(String processorname, String topicname, KStream<String, Event> events) {

	    Predicate<String, Event> isForThisProcessor = (k, v) -> v.getSource().toString().toLowerCase().hashCode() == processorname.toLowerCase().hashCode();
	    
	    KStream routedEvents = events.filter(isForThisProcessor);
	    routedEvents.foreach(new ForeachAction<String, Event>() {
	        public void apply(String key, Event value) {
	            System.out.println("check value: " + key + ": " + value + "\r\n");
	            totalProcessedEvents.addAndGet(1L);
	        }
	     });

	    System.out.print("route event to topic - '" + topicname + "' for processor : '" + processorname + "'\r\n");
	   
	    routedEvents.to(topicname, Produced.with(stringSerde, eventSerde));
		
	}
	
    /**
     * Now that we have finished the definition of the processing topology we can actually run
     * it via `start()`.  The Streams application as a whole can be launched just like any
     * normal Java application that has a `main()` method.
     * @throws Exception
     */
	public void startStreaming() throws Exception {
    
        final KafkaStreams streams = buildEventStreams();
        this.kafkaStreams = streams;
        // Always (and unconditionally) clean local state prior to starting the processing topology.
        // We opt for this unconditional call here because this will make it easier for you to play around with the example
        // when resetting the application for doing a re-run (via the Application Reset Tool,
        // http://docs.confluent.io/current/streams/developer-guide.html#application-reset-tool).
        //
        // The drawback of cleaning up local state prior is that your app must rebuilt its local state from scratch, which
        // will take time and will require reading all the state-relevant data from the Kafka cluster over the network.
        // Thus in a production scenario you typically do not want to clean up always as we do here but rather only when it
        // is truly needed, i.e., only under certain conditions (e.g., the presence of a command line flag for your app).
        
        streams.cleanUp();
        System.out.print(Thread.currentThread().getName() + ": Start streaming ...");
        streams.start();
        
        // Add shutdown hook to respond to SIGTERM and gracefully close Kafka Streams
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
          @Override
          public void run() {
            streams.close();
            kafkaStreams = null;
          }
        }));   
    }
	
	public void stopStreaming() throws Exception {
		if (kafkaStreams != null)
			this.kafkaStreams.close();
	}
}
